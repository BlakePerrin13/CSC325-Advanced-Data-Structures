# should not contain sytax error
myName = 'Blake Perrin'
myTechID = '10382316'
myTechEmail = 'bep020' #only your email id omit @latech.edu
